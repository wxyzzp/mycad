#if !defined(AFX_OPTIONSSNAPPINGTAB_H__20BA0F08_8F4E_4B62_8E51_A2573DF604F7__INCLUDED_)
#define AFX_OPTIONSSNAPPINGTAB_H__20BA0F08_8F4E_4B62_8E51_A2573DF604F7__INCLUDED_

#include "..\LIB\ICADLIB\Icadlib.h"	// Added by ClassView
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// OptionsSnappingTab.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// OptionsSnappingTab dialog

class OptionsSnappingTab : public CPropertyPage
{
	DECLARE_DYNCREATE(OptionsSnappingTab)

// Construction
public:
	OptionsSnappingTab();
	~OptionsSnappingTab();

// Dialog Data
	//{{AFX_DATA(OptionsSnappingTab)
	enum { IDD = OPTIONS_SNAPPING };
	int		m_nMarkerSize;
	int		m_nMarkerThickness;
	BOOL	m_bAperture;
	BOOL	m_bFlyover;
	BOOL	m_bSnapView;
	BOOL	m_bTooltips;
	BOOL	m_bMarker;
	//}}AFX_DATA

public:
	BOOL DrawMarkerPreview();
	int m_nMarkerColor ;
// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(OptionsSnappingTab)
	public:
	virtual void OnOK();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(OptionsSnappingTab)
	afx_msg void OnDrawItem(int nIDCtl, LPDRAWITEMSTRUCT lpDrawItemStruct);
	afx_msg void OnScreenColor();
	afx_msg void OnDeltaposSpin1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDeltaposSpin2(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnPaint();
	afx_msg void OnCheckEnableFlyOverSnap();
	afx_msg void OnCheckDisplayToolTips();
	afx_msg void OnCheckDisplayMarker();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OPTIONSSNAPPINGTAB_H__20BA0F08_8F4E_4B62_8E51_A2573DF604F7__INCLUDED_)
