// OptionsSnappingTab.cpp : implementation file
//

#include "stdafx.h"
#include "icad.h"
#include "icadapi.h"
#include "OptionsSnappingTab.h"
#include "optionsfuncts.h"

#include "resource.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// OptionsSnappingTab property page

IMPLEMENT_DYNCREATE(OptionsSnappingTab, CPropertyPage)

OptionsSnappingTab::OptionsSnappingTab() : CPropertyPage(OptionsSnappingTab::IDD)
{
	//{{AFX_DATA_INIT(OptionsSnappingTab)
	//m_nMarkerSize = 4;
	//m_nMarkerThickness = 1;
	//m_bAperture = FALSE;
	//m_bFlyover = FALSE;
	m_bSnapView = FALSE;
	//m_bTooltips = FALSE;
	//m_bMarker = FALSE;
	//}}AFX_DATA_INIT
	// m_nMarkerColor = 2 ;
	
	resbuf rb = { 0 } ;
	
	sds_getvar("APBOX", &rb);
	if( rb.resval.rint )
		m_bAperture = TRUE ;
	else 
		m_bAperture = FALSE ;
	
	sds_getvar("SNAPCOLOR", &rb);
	m_nMarkerColor = rb.resval.rint ;
	
	sds_getvar("SNAPSIZE", &rb);
	m_nMarkerSize = rb.resval.rint ;
	
	sds_getvar("SNAPTHICKNESS", &rb);
	m_nMarkerThickness = rb.resval.rint ;
	
	sds_getvar("SNAPALLVIEWS", &rb);

	if ( rb.resval.rint  )
		m_bSnapView = 1;
	else
		m_bSnapView = 0;	
	 
	sds_getvar("AUTOSNAP", &rb);
	
	if(rb.resval.rint == 0 ) 
		m_bFlyover = FALSE;
	else 
	{
		m_bFlyover = TRUE;
		
		if( rb.resval.rint  & 1 )
			m_bMarker = TRUE ;
		else 
			m_bMarker = FALSE ;
		
		if( rb.resval.rint & 2 )
			m_bTooltips = TRUE ;
		else 
			m_bTooltips = FALSE ;	
	}
}

OptionsSnappingTab::~OptionsSnappingTab()
{
}

void OptionsSnappingTab::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(OptionsSnappingTab)
	DDX_Text(pDX, IDC_EDIT1, m_nMarkerSize);
	DDV_MinMaxInt(pDX, m_nMarkerSize, 1, 20);
	DDX_Text(pDX, IDC_EDIT2, m_nMarkerThickness);
	DDV_MinMaxInt(pDX, m_nMarkerThickness, 1, 4);
	DDX_Check(pDX, OPTION_APERTURE, m_bAperture);
	DDX_Check(pDX, OPTION_FLYOVER, m_bFlyover);
	DDX_Check(pDX, OPTION_SNAP_VIEW, m_bSnapView);
	DDX_Check(pDX, OPTION_TOOLTIPS, m_bTooltips);
	DDX_Check(pDX, OPTIONS_MARKER, m_bMarker);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(OptionsSnappingTab, CPropertyPage)
	//{{AFX_MSG_MAP(OptionsSnappingTab)
	ON_WM_DRAWITEM()
	ON_BN_CLICKED(OPTION_SCREEN_COLOR, OnScreenColor)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN1, OnDeltaposSpin1)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN2, OnDeltaposSpin2)
	ON_WM_PAINT()
	ON_BN_CLICKED(OPTION_FLYOVER,  OnCheckEnableFlyOverSnap )
	ON_BN_CLICKED(OPTION_TOOLTIPS, OnCheckDisplayToolTips )
	ON_BN_CLICKED(OPTIONS_MARKER, OnCheckDisplayMarker )
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// OptionsSnappingTab message handlers

void OptionsSnappingTab::OnDrawItem(int nIDCtl, LPDRAWITEMSTRUCT lpDrawItemStruct) 
{
	// TODO: Add your message handler code here and/or call default
	switch(nIDCtl)
	{
	case OPTION_SCREEN_COLOR:

		DrawColorButton(lpDrawItemStruct, this, OPTION_SCREEN_COLOR, m_nMarkerColor, false);
		break;

	default:
		CPropertyPage::OnDrawItem(nIDCtl, lpDrawItemStruct);
	}
}

void OptionsSnappingTab::OnScreenColor() 
{
	// TODO: Add your control notification handler code here
	SDS_GetColorDialog(m_nMarkerColor ,&m_nMarkerColor ,3 ) ;

	// Update color swatch
	PaintColorSwatch(this, OPTION_SCREEN_COLOR, m_nMarkerColor , false );
	DrawMarkerPreview() ;
}

void OptionsSnappingTab::OnDeltaposSpin1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)pNMHDR;
	// TODO: Add your control notification handler code here

    UpdateData(TRUE);
    m_nMarkerSize+=(-pNMUpDown->iDelta);

    if (m_nMarkerSize < 1) m_nMarkerSize = 1;
	if (m_nMarkerSize > 20) m_nMarkerSize = 20;

    UpdateData(FALSE);
	DrawMarkerPreview() ;
	*pResult = 0;
}

BOOL OptionsSnappingTab::DrawMarkerPreview()
{
	CRect rect;
	CBrush brush;
    CWnd *hItemWnd = GetDlgItem(OPTIONS_SNAPPING_PIC );
    CDC *buttonDC = hItemWnd->GetDC();
	CPalette *oldpal= buttonDC->SelectPalette(SDS_CMainWindow->m_pPalette,TRUE);
	bool checkBackgrd = true;
	buttonDC->RealizePalette();	

	resbuf rb ;
	sds_getvar( "BKGCOLOR", &rb ) ;
	int color = rb.resval.rint ;
	
	SDS_getvar(NULL, DB_QBKGCOLOR, &rb, SDS_CURDWG, &SDS_CURCFG, &SDS_CURSES);

	if (checkBackgrd && (rb.resval.rint == color))
	{
		brush.CreateSolidBrush(SDS_BrushColorFromACADColor(256));
	}
	else
	{
		if (color == 256)
			brush.CreateSolidBrush(RGB(0,0,0));

		else
			brush.CreateSolidBrush(SDS_BrushColorFromACADColor(color));
	}

    hItemWnd->GetClientRect(&rect);

	buttonDC->FillRect(&rect, &brush); 	
	
	CBrush* pOldBrush = buttonDC->SelectObject(&brush);
	HGDIOBJ hOldPen = SelectObject(buttonDC->m_hDC, CreatePen(PS_SOLID,m_nMarkerThickness,SDS_PenColorFromACADColor(m_nMarkerColor)));
	buttonDC->SetWindowOrg( (rect.left - rect.right)/2 , (rect.top - rect.bottom)/2 ) ;
	buttonDC->Rectangle( -m_nMarkerSize, -m_nMarkerSize, m_nMarkerSize, m_nMarkerSize ) ;
	SelectObject(buttonDC->m_hDC,hOldPen);
	buttonDC->SelectObject(&pOldBrush);

	brush.DeleteObject();
	buttonDC->SelectPalette(oldpal, TRUE);
	hItemWnd->ReleaseDC(buttonDC);
	return TRUE ;	
}

void OptionsSnappingTab::OnDeltaposSpin2(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)pNMHDR;
	// TODO: Add your control notification handler code here
    m_nMarkerThickness+=(-pNMUpDown->iDelta);

    if (m_nMarkerThickness < 1) m_nMarkerThickness = 1;
	if (m_nMarkerThickness > 4) m_nMarkerThickness = 4;

    UpdateData(FALSE);
	DrawMarkerPreview() ;
	*pResult = 0;
}

void OptionsSnappingTab::OnOK() 
{
	// TODO: Add your specialized code here and/or call the base class
	resbuf rb = { 0 } ;
    rb.restype=RTSHORT;
	
	rb.resval.rint = m_bAperture ;
	sds_setvar("APBOX", &rb);
	
	rb.resval.rint = m_nMarkerColor ;
	sds_setvar("SNAPCOLOR", &rb);

	rb.resval.rint = m_nMarkerSize ;
	sds_setvar("SNAPSIZE", &rb);
	
	rb.resval.rint = m_nMarkerThickness ;
	sds_setvar("SNAPTHICKNESS", &rb);

	if ( m_bSnapView )
		rb.resval.rint = 1;
	else
		rb.resval.rint = 0;
	sds_setvar("SNAPALLVIEWS", &rb);	

	sds_getvar( "AUTOSNAP", &rb ) ;

	if( m_bFlyover == FALSE )
		rb.resval.rint = 0 ;
	else
	{		
		if( m_bTooltips )
			rb.resval.rint |= 2 ;
		else 
			rb.resval.rint &= 0xfffd ;
		
		if( m_bMarker )
			rb.resval.rint |= 1 ;
		else 
			rb.resval.rint &= 0xfffe ;		
	}

	sds_setvar( "AUTOSNAP" , &rb ) ;

	CPropertyPage::OnOK();
}


void OptionsSnappingTab::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	CDialog::OnPaint();

	// TODO: Add your message handler code here
	DrawMarkerPreview() ;
	// Do not call CPropertyPage::OnPaint() for painting messages
}

void OptionsSnappingTab::OnCheckEnableFlyOverSnap()
{
	if ( (( CButton * )GetDlgItem(OPTION_FLYOVER))->GetCheck() == 0 )
	{			
		(( CButton * )GetDlgItem(OPTION_TOOLTIPS))->SetCheck(0); 			
		(( CButton * )GetDlgItem(OPTIONS_MARKER) )->SetCheck(0); 
	}
	else
	{
		(( CButton * )GetDlgItem(OPTION_TOOLTIPS))->SetCheck(1); 			
		(( CButton * )GetDlgItem(OPTIONS_MARKER) )->SetCheck(1); 
	}
	
}

void OptionsSnappingTab::OnCheckDisplayToolTips( )
{
	if ( (( CButton * )GetDlgItem(OPTION_TOOLTIPS))->GetCheck() == 0 &&
		 (( CButton * )GetDlgItem(OPTIONS_MARKER) )->GetCheck() == 0	)
	{
		(( CButton * )GetDlgItem(OPTION_FLYOVER))->SetCheck(0); 			
	}
	else
	{
		(( CButton * )GetDlgItem(OPTION_FLYOVER))->SetCheck(1); 			
	}

}

void OptionsSnappingTab::OnCheckDisplayMarker()
{	
	if ( (( CButton * )GetDlgItem(OPTION_TOOLTIPS))->GetCheck() == 0 &&
		 (( CButton * )GetDlgItem(OPTIONS_MARKER) )->GetCheck() == 0    )
	{
		(( CButton * )GetDlgItem(OPTION_FLYOVER))->SetCheck(0); 			
	}
	else
	{
		(( CButton * )GetDlgItem(OPTION_FLYOVER))->SetCheck(1); 			
	}
}