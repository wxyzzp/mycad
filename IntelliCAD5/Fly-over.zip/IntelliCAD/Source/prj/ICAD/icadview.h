/* D:\ICADDEV\PRJ\ICAD\ICADVIEW.H
 * Copyright (C) 1997-1998 Visio Corporation. All rights reserved.
 * 
 * Abstract
 * 
 * CIcadView class-- drawings, viewports
 * 
 */ 

#pragma once

#include "IcadApi.h"
#include "gr.h"
#include <afxole.h>
#include <afxcmn.h>

#include "IcadToolTip.h"

class CRealTime;
class BaseDrawDevice;
class CMainWindow;
class CIcadCntrItem;
class OffscreenFrameBuffer;

const UINT RealTimeTimer_id = 1974;		// some ID
const UINT RealTimeTimer_time = 26;		// elapse time

enum RealTimeMotions
{
	NO,
	ZOOM,
	ZOOM_WHEEL,
	PAN,
	ROT_CYL,
	ROT_CYL_X,
	ROT_CYL_Y,
	ROT_CYL_Z,
	ROT_SPH
};

typedef struct tagsnapstruct {		
	sds_point pt;
	int nSnappedType;
	bool bValidSnap;		
}SNAPSTRUCT;

typedef struct tagSnapInfoData  {
	char		SnapName[4];
	int			nSnapPriority;
	double		dDistance;
	int			nSnappedType;
	SNAPSTRUCT  SnapStruct;
}SNAPINFODATA;

class	SnapInfo {
public :
	SnapInfo()
	{
		nNextSnapData = 0;
	}
	struct gr_view *view;
	CIcadView *View;
	SNAPSTRUCT PrevSnapStruct;	
	CPoint CursorPoint;
	sds_point m_lastsnappoint;
	sds_point Comparept;
	CString strTipText;
	int m_nSnapDrawn;
	CDC * pDC ;
	//float fSnapSize	;
	int snapsize;
	int thickness ;
	int bgkcolor	;
	int snapcolor ;
	int osmode;
	int showtooltips;
	int nNoOfSnapType;
	int autosnap;
	int marker;	
	
	int nNextSnapData;
	SNAPSTRUCT TempSnapStruct;
	SNAPINFODATA SnapData[12];
	
	void Initialise();
	void InitialiseSnapData();
	SNAPSTRUCT TryEntitySnap(CPoint &Point);
	SNAPSTRUCT GetNextSnapData();
	void SetLatestValues();
	void DeleteSnap();
	void DrawSnap(SNAPSTRUCT &SnapData);

	void DrawSnapForEND(int ptx, int pty, CPen &pen);
	void DrawSnapForMID(int ptx, int pty, CPen &pen);
	void DrawSnapForINT(int ptx, int pty, CPen &pen);
	void DrawSnapForNEA(int ptx, int pty, CPen &pen);	
	void DrawSnapForCEN(int ptx, int pty, CPen &pen);
	void DrawSnapForQUA(int ptx, int pty, CPen &pen);
	void DrawSnapForTAN(int ptx, int pty, CPen &pen);
	void DrawSnapForPER(int ptx, int pty, CPen &pen);
	void DrawSnapForINS(int ptx, int pty, CPen &pen);
	void DrawSnapForNOD(int ptx, int pty, CPen &pen);
};

class CIcadView : public CView
{
	DECLARE_DYNCREATE(CIcadView)

public:
	CIcadView();
	virtual ~CIcadView();
	CIcadDoc* GetDocument();
	db_drawing *GetDrawing();
	void SetNewView(bool bSetFocus, bool callback=TRUE);
  void UpdateCoords(sds_point pt,int coords);
    void CalcViewPoints(int UpdateTab);

	CMainWindow* m_pMain;
	CIcadCntrItem* m_pSelection;
	COleDropTarget m_dropTarget;

    //*** Cursor member variables
public:
	void CursorDown( CPoint);
	bool CursorOn( bool);
	bool CrossHairCleared( bool);
	UINT CursorID( UINT);

    bool	m_CursorOn;
    CPoint  m_LastCursorPos;
    short   m_LastCursorType;

protected:
    HCURSOR m_prevCursor;
    UINT    m_idcCursor; //*** ID for the cursor to be displayed in the view window.
    short   m_CursorType;
    CPoint  m_CursorDownPos;
	bool	m_bCrosshairCleared;

	CIcadToolTip m_toolTip;

public:
    CRect   m_rectMspace;
	BOOL    m_bEatNextMouse;
	int     m_iViewMode;  // 0=Normal 1=Hidden line 2=Shaded.

	int     m_iWinX;
	int     m_iWinY;

    short   m_fUseRegenList;
	int     m_LastCol,m_LastHl,m_LastRop,m_LastWid;
	int     m_FillLastCol,m_FillLastHl,m_FillLastRop;
	BOOL    m_bMakingSld;
	BOOL    m_bNeedRedraw;
	BOOL    m_bReScaleOnce;
	struct SDS_prevview *m_pZoomPrevB,*m_pZoomPrevC;
	struct SDS_prevview *m_pZoomPsPrevB,*m_pZoomPsPrevC;
	int     m_iPrevViews;
	int     m_iPrevPsViews;
	CRect  *m_pClipRectDC;
	CRect  *m_pClipRectMemDC;
    struct resbuf *m_pDragVects;
	double m_dViewSizeAtLastRegen;
    //*** Save varaibles for printing
	BOOL	  m_bAltView;
	sds_real  m_rPrintViewSize,m_rPrintLensLength,m_rPrintFrontZ,m_rPrintBackZ,
			  m_rPrintViewTwist;
	sds_point m_ptPrintViewCtr,m_ptPrintViewDir,m_ptPrintTarget,m_ptPrintScreenSize;
	int		  m_nPrintViewMode;
	sds_point m_ptLwrLeft,m_ptUprRight;
	CRect	  m_PrintClipRect;
	CSize	  m_sizePrintView;
	BOOL	  m_bNeedRestoreView;
	bool	  m_showScrollBars;

	CRealTime*		m_pRealTime;
	RealTimeMotions	m_RTMotion;

    //*** Entity drawing variables
	POINT  *m_pPolyPts;
	int     m_nPolyPts;
	//*** Pointer to this view's dwg struct
	CIcadDoc* m_pViewsDoc;
	struct gr_view *m_pCurDwgView;
	db_handitem *m_pVportTabHip;
	short m_RectBitBlt;
    POINT m_RectBitBltPt[2];
	//*** Printing member functions
	virtual void FilePrint(BOOL bShowPrintDlg);
	virtual void FilePrintPreview(void);
	void PrintHeaderOrFooter(CDC* pDC, BOOL bPrintHeader);
	void SavePrintViewInfo(struct sds_resbuf* pRb);
	void RestorePrintViewInfo();
	void OnInsertObject(LPCTSTR pszFileName);
	void OnInsertObject();
	CIcadCntrItem* HitTestItems(CPoint point);
	void SetSelection(CIcadCntrItem* pItem, BOOL bForceRedrawAll = FALSE);
	virtual void OnDraw(CDC* pDC);

	virtual void OnInitialUpdate();
	virtual BOOL PreTranslateMessage(MSG* pMsg);

	void ShowScrollBar(UINT nBar, BOOL bShow = TRUE);
	void UpdateScrollBars(void);
	void CopyToClipboard();
	BOOL CreatePictureFromSS(sds_name ssEnts, HBITMAP* phBmp,
		HENHMETAFILE* phEnhMetaFile, ICADWMFINFO* pWmfInfo, HANDLE* phIcadData,
		BOOL bPaintBkgnd, BOOL bHIMETRIC = FALSE);
	void EsnapContextMenu(CPoint point);
	void OleContextMenu(CPoint point);
	void OnOleContextMenuPick(UINT nId);

	void processOsnapChar( UINT nChar );
	void updateToolTip(){ m_toolTip.Update(); }

	int SaveBitmapToBuffer( char **ppBuffer, long *bytes, bool ChgBackgnd );

	OffscreenFrameBuffer *GetFrameBuffer( void )
		{
		return this->m_pFrameBuffer;
		}
	
	SnapInfo SnapObject;
	CToolTipCtrl m_ctlToolTip;
	CPoint PrevPoint;
	int count;

	// This is an optimization.  Ideally we wouldn't keep a draw device
	// around all the time, but new and delete are slow and we sometimes
	// use these a lot
	//
	BaseDrawDevice *GetFrameBufferDrawDevice( void )
		{
		return this->m_pFrameBufferDrawDevice;
		}

	HDC	GetFrameBufferDC( void );
	CDC *GetFrameBufferCDC( void );
	CDC *GetTargetDeviceCDC( void );
	bool IsPrinting( void );

	void SetDcFillColorMem(int color, int hl, int rop, BaseDrawDevice *pDevice = NULL );
	void SetDcColorMem(int color, int width, int hl, int rop, BaseDrawDevice *pDevice = NULL );

	BaseDrawDevice *GetDrawDevice( void );
	bool ReleaseDrawDevice( BaseDrawDevice *pDevice );


	BOOL m_bIsTempView;
	BOOL m_bDontDelInTab;

	BOOL m_bSizeInPlace;
	BOOL m_bInPlaceDeactivated;
	double m_dPreInPlaceViewSize;


	// PRIVATE OPERATIONS
	//
private:
	void	setPrinterDC( CDC *pCDC );
	void	clearPrinterDC( void );
	CDC		*getPrinterDC( void );

	// AG: custom tooltip processing
	void FilterToolTipMessage( MSG *pMsg );
	void RelayToolTipMessage( const MSG *pMsg );


private:

	OffscreenFrameBuffer	*m_pFrameBuffer;

	// This is an optimization.  Ideally we wouldn't keep a draw device
	// around all the time, but new and delete are slow and we sometimes
	// use these a lot
	//
	BaseDrawDevice			*m_pFrameBufferDrawDevice;

	// This is only set if we are currently printing
	// otherwise it is NULL
	//
	CDC						*m_pCurrentPrinterDC;
	BaseDrawDevice			*m_printerDrawDevice;
	CPalette				*m_oldPrinterPalette;
	
protected:

	//{{AFX_MSG(CIcadView)
    afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
    afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
    afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
    afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
    afx_msg BOOL OnEraseBkgnd(CDC* pDC);
    afx_msg void OnPaint(void);
    afx_msg void OnSize(UINT nType, int cx, int cy);
    afx_msg void OnMove(int cx, int cy);
    afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
    afx_msg void OnMouseMove(UINT nFlags, CPoint point);
    afx_msg void OnMButtonDown(UINT nFlags, CPoint point);
    afx_msg void OnMButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMButtonDblClk(UINT nFlags, CPoint point);
    afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
    afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
    afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
    afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
	afx_msg void OnTimer(UINT nIDEvent);
	//}}AFX_MSG
	afx_msg BOOL OnQueryNewPalette();
	afx_msg void OnPaletteChanged(CWnd* pFocusWnd);
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	afx_msg virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	afx_msg virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	afx_msg virtual void OnPrint(CDC* pDC, CPrintInfo* pInfo);
	afx_msg virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	// Ole messages
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	afx_msg virtual BOOL IsSelected(const CObject* pDocItem) const;// Container support
	afx_msg void OnCancelEditCntr();
	afx_msg void OnCancelEditSrvr();
	virtual DROPEFFECT OnDragOver(COleDataObject* pDataObject, DWORD dwKeyState,
		CPoint point);
	virtual DROPEFFECT OnDropEx(COleDataObject* pDataObject, DROPEFFECT dropDefault,
		DROPEFFECT dropList, CPoint point);
	//*** Cursor member functions
    afx_msg void OnCaptureChanged(CWnd* pWnd);
	virtual void OnActivateView( BOOL bActivate, CView* pActivateView, CView* pDeactiveView );

	//*** ToolTip member functions
	afx_msg BOOL OnToolTipText(UINT nID, NMHDR* pNMHDR, LRESULT* pResult);
	virtual int OnToolHitTest( CPoint pt, TOOLINFO* pTI ) const;

	DECLARE_MESSAGE_MAP()

};

// PP
#define END		2
#define NEA		4
#define PER		6
#define QUA		8
#define INS		10
#define CEN		12
#define MID		14
#define NOD		16
#define TAN		18
#define QUI		20
#define INTR	22
// PP
